'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'

export default function ReflectionPage() {
  const router = useRouter()
  const [reflection, setReflection] = useState<string | null>(null)
  const [reReflection, setReReflection] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const [inputs, setInputs] = useState<{
    decision: string
    options: string
    fears: string
    values: string
    extra: string
    guide: string
  } | null>(null)

  useEffect(() => {
    const storedEntry = localStorage.getItem('latest_reflection')
    if (!storedEntry) {
      router.push('/reflect')
    } else {
      const parsed = JSON.parse(storedEntry)
      setReflection(parsed.reflection)
      setInputs({
        decision: parsed.decision,
        options: parsed.options,
        fears: parsed.fears,
        values: parsed.values,
        extra: parsed.extra,
        guide: parsed.guide,
      })
    }
  }, [router])

  const handleReReflect = async () => {
    if (!inputs) return
    setLoading(true)
    setReReflection(null)
    try {
      const res = await fetch('/api/reflect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...inputs,
          mode: 'reframe',
        }),
      })
      const data = await res.json()
      setReReflection(data.reflection)
    } catch (err) {
      setReReflection('Something went wrong. Please try again later.')
    } finally {
      setLoading(false)
    }
  }

  const handleStartOver = () => {
    localStorage.removeItem('latest_reflection')
    router.push('/')
  }

  if (!reflection || !inputs) return null

  return (
    <div className="max-w-3xl mx-auto px-4 py-10 text-white space-y-10">
      <h1 className="text-3xl font-bold text-center mb-6 drop-shadow">🪞 Your Guided Reflection</h1>

      <div className="space-y-4 bg-white/10 p-6 rounded-2xl shadow-lg">
        <p className="text-lg text-gray-200"><strong>Guide:</strong> {inputs.guide}</p>
        <p><strong>🧠 Decision:</strong> {inputs.decision}</p>
        <p><strong>✍️ Options:</strong> {inputs.options}</p>
        <p><strong>😨 Fears:</strong> {inputs.fears}</p>
        <p><strong>💡 Values:</strong> {inputs.values}</p>
        {inputs.extra && <p><strong>🗒️ Extra:</strong> {inputs.extra}</p>}
      </div>

      <div className="space-y-2 bg-white/5 p-6 rounded-2xl shadow">
        <h2 className="text-xl font-semibold text-blue-200">🧘 Insight from {inputs.guide}</h2>
        <p className="whitespace-pre-wrap leading-relaxed text-blue-100">{reflection}</p>
      </div>

      <div className="text-center">
        <button
          onClick={handleReReflect}
          className="mt-6 px-6 py-3 bg-white/20 hover:bg-white/30 rounded-xl text-white font-semibold"
          disabled={loading}
        >
          🔁 Re-reflect from a different angle
        </button>
      </div>

      {loading && (
        <p className="text-center text-sm text-gray-300 italic">Re-thinking with your guide...</p>
      )}

      {reReflection && (
        <div className="space-y-2 bg-white/10 p-6 rounded-2xl shadow border border-blue-200">
          <h2 className="text-lg font-semibold text-blue-100">🔁 Alternate Perspective</h2>
          <p className="whitespace-pre-wrap leading-relaxed text-blue-100">{reReflection}</p>
        </div>
      )}

      <div className="text-center pt-6">
        <button
          onClick={handleStartOver}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition"
        >
          📝 Start a New Reflection
        </button>
      </div>
    </div>
  )
}