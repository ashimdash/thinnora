// lib/usageLimit.ts

const HARDCODED_WHITELIST = [
  'dash.ashim@gmail.com',
  'panigrahisangeeta4@gmail.com',
  'sunitapanigrahi66@gmail.com',
  'debi2987@gmail.com',
  'bhagyashree325@gmail.com'
]

export function canReflectToday(email: string | null): boolean {
  if (email && HARDCODED_WHITELIST.includes(email.toLowerCase())) {
    return true
  }

  const today = new Date().toISOString().split('T')[0]
  const key = `reflections_${today}`
  const count = parseInt(localStorage.getItem(key) || '0', 10)

  return count < 2
}

export function recordReflection(): void {
  const today = new Date().toISOString().split('T')[0]
  const key = `reflections_${today}`
  const current = parseInt(localStorage.getItem(key) || '0', 10)
  localStorage.setItem(key, (current + 1).toString())
}

export function getRemainingReflections(email: string | null): number {
  if (email && HARDCODED_WHITELIST.includes(email.toLowerCase())) {
    return Infinity
  }

  const today = new Date().toISOString().split('T')[0]
  const key = `reflections_${today}`
  const count = parseInt(localStorage.getItem(key) || '0', 10)

  return 2 - count
}